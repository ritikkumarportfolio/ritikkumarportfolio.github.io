import React from 'react';
import { SparkleIcon } from './Decoration';

interface SectionHeaderProps {
  title: string;
}

const SectionHeader: React.FC<SectionHeaderProps> = ({ title }) => {
  return (
    <div className="flex items-center gap-2 mb-6 text-ink">
      <SparkleIcon className="w-6 h-6 fill-ink" />
      <h2 className="text-3xl font-serif font-bold tracking-wide uppercase">{title}</h2>
    </div>
  );
};

export default SectionHeader;