import React from 'react';
import { Mail, Linkedin, Globe, Phone } from 'lucide-react';
import SectionHeader from './SectionHeader';

const Contact: React.FC = () => {
  return (
    <div className="mt-12">
      <SectionHeader title="CONTACT" />
      <div className="flex flex-col gap-4 font-sans text-lg">
        <a href="mailto:angele.bappel@outlook.fr" className="flex items-center gap-3 hover:text-vintage-purple transition-colors">
          <div className="p-2 border-2 border-ink rounded-full bg-white">
             <Mail size={20} />
          </div>
          <span>angele.bappel@outlook.fr</span>
        </a>
        <a href="#" className="flex items-center gap-3 hover:text-vintage-purple transition-colors">
          <div className="p-2 border-2 border-ink rounded-full bg-white">
            <Globe size={20} />
          </div>
          <span>behance.net/angelebappel</span>
        </a>
        <a href="#" className="flex items-center gap-3 hover:text-vintage-purple transition-colors">
          <div className="p-2 border-2 border-ink rounded-full bg-white">
             <Linkedin size={20} />
          </div>
          <span>linkedin.com/in/angèle-bappel</span>
        </a>
      </div>
    </div>
  );
};

export default Contact;