import React from 'react';
import { NAV_CATEGORIES } from '../constants';

const NavBar: React.FC = () => {
  return (
    <nav className="w-full border-y-2 border-ink py-3 my-8 overflow-x-auto">
      <div className="flex justify-between min-w-max px-4 gap-6 md:gap-0">
        {NAV_CATEGORIES.map((category, index) => (
          <span key={index} className="text-sm font-sans font-bold tracking-wider text-ink/70 hover:text-ink cursor-pointer transition-colors whitespace-nowrap">
            {category}
          </span>
        ))}
      </div>
    </nav>
  );
};

export default NavBar;