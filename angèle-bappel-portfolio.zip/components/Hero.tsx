import React from 'react';
import { StarIcon } from './Decoration';

const Hero: React.FC = () => {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
      {/* Left Column - Illustration Placeholder */}
      <div className="relative border-2 border-ink rounded-3xl overflow-hidden min-h-[400px] bg-[#E8E1D5] shadow-vintage">
        <img 
          src="https://picsum.photos/800/800?random=10" 
          alt="Artist Illustration" 
          className="w-full h-full object-cover opacity-90 mix-blend-multiply" 
        />
        <div className="absolute top-4 right-4 bg-white border-2 border-ink rounded-full px-4 py-1 font-bold text-sm shadow-vintage-sm">
          HIRE ME!
        </div>
      </div>

      {/* Right Column - Intro */}
      <div className="flex flex-col justify-center relative p-4">
        <div className="absolute -top-6 -right-4 text-ink hidden md:block">
           <StarIcon className="w-12 h-12 text-ink" />
        </div>
        
        <div className="relative mb-6">
           <StarIcon className="absolute -left-8 top-2 w-8 h-8 text-vintage-orange" />
           <h1 className="text-7xl md:text-8xl font-serif font-black text-ink mb-2">
            HELLO !
           </h1>
           <StarIcon className="absolute right-12 bottom-2 w-6 h-6 text-vintage-purple" />
        </div>
        
        <h2 className="text-2xl font-serif mb-4">
          I'm Angèle <br />
          <span className="text-ink/60">& I'm a Jr Art Director.</span>
        </h2>
        
        <p className="font-sans text-lg leading-relaxed mb-8 max-w-md">
          I am a graphic designer based in Paris. Passionate about illustration, I create graphic projects overflowing with color. Always ready to experiment and exchange with other creatives.
        </p>
        
        <div className="flex gap-3">
          <span className="border-2 border-ink px-4 py-1 rounded-full font-bold bg-white shadow-vintage-sm">ILLUSTRATION</span>
          <span className="border-2 border-ink px-4 py-1 rounded-full font-bold bg-white shadow-vintage-sm">MOTION</span>
        </div>
      </div>
    </section>
  );
};

export default Hero;